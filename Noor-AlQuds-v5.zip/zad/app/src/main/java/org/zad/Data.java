package org.zad;
import android.content.*;import org.json.*;import java.io.*;import java.util.*;import java.text.Normalizer;
class Data {
 static JSONArray rows; static JSONObject root; static final Random rng=new Random();
 static synchronized void load(Context c){if(rows!=null)return;try(InputStream in=c.getAssets().open("hadith.json")){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);root=new JSONObject(b.toString("UTF-8"));rows=root.getJSONArray("hadiths");}catch(Exception e){rows=new JSONArray();root=new JSONObject();}}
 static SharedPreferences prefs(Context c){return c.getSharedPreferences("noor_v3",0);}
 static JSONObject at(Context c,int i){load(c);JSONObject j=rows.optJSONObject(i);return j==null?new JSONObject():j;}
 static String uid(Context c,int i){return at(c,i).optString("uid","row-"+i);}
 static boolean saved(Context c,int i){return prefs(c).getBoolean("saved:"+uid(c,i),false);}
 static void save(Context c,int i){prefs(c).edit().putBoolean("saved:"+uid(c,i),!saved(c,i)).apply();}
 static boolean eligible(Context c,int i){JSONObject j=at(c,i);return j.optBoolean("widget",false)&&j.optBoolean("verified",false)&&"صحيح".equals(j.optString("grade"));}
 static int index(Context c){load(c);String id=prefs(c).getString("current","");int first=-1;for(int i=0;i<rows.length();i++)if(eligible(c,i)){if(first==-1)first=i;if(uid(c,i).equals(id))return i;}return first;}
 static JSONObject item(Context c){return at(c,index(c));}
 static String source(Context c,int i){JSONObject j=at(c,i);return j.optString("source")+" • رقم "+j.optInt("number");}
 static String source(Context c){return source(c,index(c));}
 static String body(Context c){return item(c).optString("arabic","لا توجد روايات متاحة للعرض");}
 static String header(Context c){return index(c)<0?"نور القدس":"حديث قدسي • "+item(c).optString("grade");}
 static String widgetBody(Context c){return body(c);}
 static String copyText(Context c,int i){JSONObject j=at(c,i);return j.optString("arabic")+"\n\n"+source(c,i)+"\n"+j.optString("reference")+"\n"+j.optString("grading")+"\n"+j.optString("status");}
 static synchronized void random(Context c){load(c);Set<String> used=new HashSet<>(prefs(c).getStringSet("seen",Collections.emptySet()));int current=index(c);if(current>=0)used.add(uid(c,current));ArrayList<Integer> pool=new ArrayList<>();for(int i=0;i<rows.length();i++)if(eligible(c,i)&&!used.contains(uid(c,i)))pool.add(i);if(pool.isEmpty()){used.clear();for(int i=0;i<rows.length();i++)if(eligible(c,i)&&i!=current)pool.add(i);if(current>=0)used.add(uid(c,current));}if(pool.isEmpty())return;int next=pool.get(rng.nextInt(pool.size()));used.add(uid(c,next));prefs(c).edit().putString("current",uid(c,next)).putStringSet("seen",used).apply();}
 static String norm(String s){String v=Normalizer.normalize(s,Normalizer.Form.NFKD).replaceAll("\\p{M}","").replace("ـ","").replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ى','ي').toLowerCase(Locale.ROOT);StringBuilder b=new StringBuilder();for(char ch:v.toCharArray()){int d=Character.digit(ch,10);b.append(d>=0?(char)('0'+d):ch);}return b.toString();}
 static int count(Context c,String filter){load(c);int n=0;for(int i=0;i<rows.length();i++)if(matches(c,i,filter,"",""))n++;return n;}
 static boolean matches(Context c,int i,String filter,String q,String source){JSONObject j=at(c,i);boolean text=!j.optString("arabic").isEmpty(),verified=j.optBoolean("verified");switch(filter){case "all":break;case "saved":if(!saved(c,i))return false;break;case "verified":if(!verified)return false;break;case "widget":if(!eligible(c,i))return false;break;case "unreviewed":if(!text||verified)return false;break;case "locator":if(text)return false;break;default:if(!text||!filter.equals(j.optString("grade")))return false;}if(!source.isEmpty()&&!source.equals(j.optString("source")))return false;String query=norm(q.trim());if(query.matches("[0-9]+"))return query.equals(String.valueOf(j.optInt("number")));return query.isEmpty()||norm(j.optString("arabic")+" "+j.optString("source")+" "+j.optString("reference")+" "+j.optString("narrator")+" "+j.optString("grading")).contains(query);}
}
